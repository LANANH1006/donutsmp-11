package com.donutlike;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.command.argument.ItemStackArgumentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;

import java.util.*;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

/**
 * Cho do (AH) + Order (thu mua) do NGUOI CHOI thuc su dang/giao dich.
 * - /ah, /ah sell <gia>, /ah search <ten>   (toi da MAX_LISTINGS mon / nguoi)
 * - /orders, /orders create <item> <sl> <gia/item>  (gia mua cao nhat len trang 1)
 */
public class Market {
    static int maxListings() { return Admin.inum("max_listings"); }
    static int maxOrders() { return Admin.inum("max_orders"); }
    static final int PER_PAGE = 45;

    static class Listing {
        UUID seller; String sellerName; ItemStack stack; double price; long created;
        Listing(UUID s, String n, ItemStack st, double p) { seller = s; sellerName = n; stack = st; price = p; created = System.currentTimeMillis(); }
    }
    static class Order {
        UUID buyer; String buyerName; ItemStack template; int remaining; double perItem; long created;
        Order(UUID b, String n, ItemStack t, int r, double p) { buyer = b; buyerName = n; template = t; remaining = r; perItem = p; created = System.currentTimeMillis(); }
    }
    /** Dang luu xuong file (SNBT) */
    static class SavedListing { String seller, sellerName, nbt; double price; long created; }

    static final List<Listing> LISTINGS = new ArrayList<>();
    static final List<Order> ORDERS = new ArrayList<>();

    // ===== init / persistence =====
    static void init() {
        ServerLifecycleEvents.SERVER_STARTED.register(Market::restore);
        // order cua nguoi offline duoc hoan tien (escrow) de khong mat tien
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> refundOrders(handler.getPlayer().getUuid(), false));
    }

    static void restore(net.minecraft.server.MinecraftServer s) {
        DonutLike.SERVER = s;
        LISTINGS.clear();
        if (DonutLike.save.listings == null) return;
        for (SavedListing sl : DonutLike.save.listings) {
            ItemStack st = ItemIO.decode(sl.nbt);
            if (st.isEmpty()) continue;
            Listing l = new Listing(UUID.fromString(sl.seller), sl.sellerName, st, sl.price);
            l.created = sl.created;
            LISTINGS.add(l);
        }
    }

    /** goi truoc moi lan doSave() */
    static void snapshot() {
        if (DonutLike.SERVER == null) return;
        List<SavedListing> out = new ArrayList<>();
        for (Listing l : LISTINGS) {
            String nbt = ItemIO.encode(l.stack);
            if (nbt == null) continue;
            SavedListing sl = new SavedListing();
            sl.seller = l.seller.toString(); sl.sellerName = l.sellerName; sl.nbt = nbt; sl.price = l.price; sl.created = l.created;
            out.add(sl);
        }
        DonutLike.save.listings = out;
    }

    static void refundOrders(UUID buyer, boolean notify) {
        Iterator<Order> it = ORDERS.iterator();
        while (it.hasNext()) {
            Order o = it.next();
            if (!o.buyer.equals(buyer)) continue;
            DonutLike.add(buyer, o.perItem * o.remaining);
            it.remove();
        }
    }

    static long countListings(UUID u) { return LISTINGS.stream().filter(l -> l.seller.equals(u)).count(); }
    static long countOrders(UUID u) { return ORDERS.stream().filter(o -> o.buyer.equals(u)).count(); }

    // ===== lenh =====
    static void register(CommandDispatcher<ServerCommandSource> d, CommandRegistryAccess ra) {
        d.register(literal("ah").requires(s -> Admin.on("ah"))
            .executes(c -> { openAh(c.getSource().getPlayerOrThrow(), 0, null, 0); return 1; })
            .then(literal("sell").then(argument("price", DoubleArgumentType.doubleArg(0.01)).executes(c -> sell(c.getSource().getPlayerOrThrow(), DoubleArgumentType.getDouble(c, "price")))))
            .then(literal("search").then(argument("name", StringArgumentType.greedyString()).executes(c -> {
                openAh(c.getSource().getPlayerOrThrow(), 0, StringArgumentType.getString(c, "name").toLowerCase(), 0); return 1; }))));
        // alias cu
        d.register(literal("sell").requires(s -> Admin.on("ah")).then(argument("price", DoubleArgumentType.doubleArg(0.01)).executes(c -> sell(c.getSource().getPlayerOrThrow(), DoubleArgumentType.getDouble(c, "price")))));
        d.register(ordersTree("orders", ra));
        d.register(ordersTree("order", ra));
    }

    static LiteralArgumentBuilder<ServerCommandSource> ordersTree(String name, CommandRegistryAccess ra) {
        return literal(name).requires(s -> Admin.on("orders"))
            .executes(c -> { openOrders(c.getSource().getPlayerOrThrow(), 0); return 1; })
            .then(literal("create")
                .then(argument("item", ItemStackArgumentType.itemStack(ra))
                .then(argument("amount", IntegerArgumentType.integer(1, 2304))
                .then(argument("price", DoubleArgumentType.doubleArg(0.01)).executes(c -> {
                    ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                    ItemStack tpl = ItemStackArgumentType.getItemStackArgument(c, "item").createStack(1, false);
                    return createOrder(p, tpl, IntegerArgumentType.getInteger(c, "amount"), DoubleArgumentType.getDouble(c, "price"));
                })))));
    }

    static int sell(ServerPlayerEntity p, double price) {
        ItemStack hand = p.getMainHandStack();
        if (hand.isEmpty()) { DonutLike.msg(p, "§cHãy cầm vật phẩm muốn bán trên tay."); return 0; }
        if (countListings(p.getUuid()) >= maxListings()) { DonutLike.msg(p, "§cBạn chỉ được đăng tối đa " + maxListings() + " món cùng lúc."); return 0; }
        LISTINGS.add(new Listing(p.getUuid(), p.getName().getString(), hand.copy(), price));
        p.setStackInHand(Hand.MAIN_HAND, ItemStack.EMPTY);
        DonutLike.msg(p, "§aĐã đăng bán lên /ah giá $" + DonutLike.fmt(price) + " §7(" + countListings(p.getUuid()) + "/" + maxListings() + ")");
        return 1;
    }

    static int createOrder(ServerPlayerEntity p, ItemStack tpl, int amount, double per) {
        if (countOrders(p.getUuid()) >= maxOrders()) { DonutLike.msg(p, "§cTối đa " + maxOrders() + " order cùng lúc."); return 0; }
        double total = per * amount;
        if (DonutLike.bal(p.getUuid()) < total) { DonutLike.msg(p, "§cBạn cần $" + DonutLike.fmt(total) + " để đặt order này."); return 0; }
        DonutLike.add(p.getUuid(), -total); // giu tien (escrow)
        ORDERS.add(new Order(p.getUuid(), p.getName().getString(), tpl, amount, per));
        DonutLike.msg(p, "§aĐã đặt order " + amount + "x " + tpl.getName().getString() + " ($" + DonutLike.fmt(per) + "/cái). Tiền đã được giữ lại, chờ người chơi khác giao hàng.");
        return 1;
    }

    // ===== GUI helpers =====
    static ItemStack named(net.minecraft.item.Item it, String name, String... lore) {
        ItemStack s = new ItemStack(it);
        s.set(DataComponentTypes.CUSTOM_NAME, Text.literal(name));
        if (lore.length > 0) {
            List<Text> l = new ArrayList<>();
            for (String x : lore) l.add(Text.literal(x));
            s.set(DataComponentTypes.LORE, new LoreComponent(l));
        }
        return s;
    }

    static void openAh(ServerPlayerEntity p, int page, String filter, int sort) {
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (id, inv, pl) -> new AhGui(id, inv, new SimpleInventory(54), pl.getUuid(), page, filter, sort),
            Text.literal("Auction House" + (filter != null ? " [" + filter + "]" : ""))));
    }

    static void openOrders(ServerPlayerEntity p, int page) {
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (id, inv, pl) -> new OrderGui(id, inv, new SimpleInventory(54), pl.getUuid(), page),
            Text.literal("Orders (giá cao nhất trước)")));
    }

    static final String[] SORT_NAMES = {"Mới nhất", "Giá thấp → cao", "Giá cao → thấp"};

    // ===== AH GUI =====
    static class AhGui extends GenericContainerScreenHandler {
        final SimpleInventory inv; final UUID viewer; final String filter; int page, sort, pages;
        List<Listing> view = new ArrayList<>();

        AhGui(int id, PlayerInventory pinv, SimpleInventory inv, UUID viewer, int page, String filter, int sort) {
            super(ScreenHandlerType.GENERIC_9X6, id, pinv, inv, 6);
            this.inv = inv; this.viewer = viewer; this.page = page; this.filter = filter; this.sort = sort;
            refresh();
        }

        void refresh() {
            view = new ArrayList<>();
            for (Listing l : LISTINGS) {
                if (filter != null) {
                    String n = l.stack.getName().getString().toLowerCase();
                    String idp = Registries.ITEM.getId(l.stack.getItem()).getPath();
                    if (!n.contains(filter) && !idp.contains(filter.replace(' ', '_'))) continue;
                }
                view.add(l);
            }
            if (sort == 0) view.sort((a, b) -> Long.compare(b.created, a.created));
            else if (sort == 1) view.sort(Comparator.comparingDouble(a -> a.price));
            else view.sort((a, b) -> Double.compare(b.price, a.price));
            pages = Math.max(1, (view.size() + PER_PAGE - 1) / PER_PAGE);
            page = Math.max(0, Math.min(page, pages - 1));

            for (int i = 0; i < 54; i++) inv.setStack(i, ItemStack.EMPTY);
            for (int i = 0; i < PER_PAGE; i++) {
                int idx = page * PER_PAGE + i;
                if (idx >= view.size()) break;
                Listing l = view.get(idx);
                boolean own = l.seller.equals(viewer);
                ItemStack d = l.stack.copy();
                d.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                    Text.literal("§eGiá: $" + DonutLike.fmt(l.price)),
                    Text.literal("§7Người bán: " + l.sellerName),
                    Text.literal(own ? "§cClick để huỷ bán" : "§aClick để mua"))));
                inv.setStack(i, d);
            }
            for (int i = 45; i < 54; i++) inv.setStack(i, named(Items.GRAY_STAINED_GLASS_PANE, " "));
            if (page > 0) inv.setStack(45, named(Items.ARROW, "§e← Trang trước"));
            inv.setStack(48, named(Items.HOPPER, "§bSắp xếp: " + SORT_NAMES[sort], "§7Click để đổi"));
            inv.setStack(49, named(Items.PAPER, "§fTrang " + (page + 1) + "/" + pages, "§7" + view.size() + " món"));
            if (page < pages - 1) inv.setStack(53, named(Items.ARROW, "§eTrang sau →"));
        }

        @Override
        public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
            if (slot >= 0 && slot < 54 && type == SlotActionType.PICKUP && player instanceof ServerPlayerEntity sp) {
                if (slot == 45 && page > 0) reopen(sp, page - 1, sort);
                else if (slot == 53 && page < pages - 1) reopen(sp, page + 1, sort);
                else if (slot == 48) reopen(sp, 0, (sort + 1) % 3);
                else if (slot < PER_PAGE) {
                    int idx = page * PER_PAGE + slot;
                    if (idx < view.size()) click(sp, view.get(idx));
                    refresh();
                }
            }
            syncState(); // chan moi thao tac keo tha
        }

        void reopen(ServerPlayerEntity sp, int pg, int so) {
            sp.getServer().execute(() -> openAh(sp, pg, filter, so));
        }

        void click(ServerPlayerEntity sp, Listing l) {
            if (!LISTINGS.contains(l)) { DonutLike.msg(sp, "§cMón này vừa bị mua/huỷ."); return; }
            if (l.seller.equals(sp.getUuid())) {
                if (!ShopHandler.canReceiveStack(sp, l.stack)) return;
                LISTINGS.remove(l);
                sp.getInventory().offerOrDrop(l.stack);
                DonutLike.msg(sp, "§eĐã huỷ bán, vật phẩm đã trả lại.");
            } else if (DonutLike.bal(sp.getUuid()) < l.price) {
                DonutLike.msg(sp, "§cBạn không đủ tiền ($" + DonutLike.fmt(l.price) + ").");
            } else {
                if (!ShopHandler.canReceiveStack(sp, l.stack)) return;
                LISTINGS.remove(l);
                DonutLike.add(sp.getUuid(), -l.price);
                DonutLike.add(l.seller, l.price);
                ServerPlayerEntity seller = sp.getServer().getPlayerManager().getPlayer(l.seller);
                if (seller != null) DonutLike.msg(seller, "§a[AH] " + sp.getName().getString() + " đã mua "
                    + l.stack.getName().getString() + " với giá $" + DonutLike.fmt(l.price));
                sp.getInventory().offerOrDrop(l.stack);
                DonutLike.msg(sp, "§aĐã mua " + l.stack.getName().getString() + " với giá $" + DonutLike.fmt(l.price));
            }
        }

        @Override public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
    }

    // ===== ORDER GUI =====
    static class OrderGui extends GenericContainerScreenHandler {
        final SimpleInventory inv; final UUID viewer; int page, pages;
        List<Order> view = new ArrayList<>();

        OrderGui(int id, PlayerInventory pinv, SimpleInventory inv, UUID viewer, int page) {
            super(ScreenHandlerType.GENERIC_9X6, id, pinv, inv, 6);
            this.inv = inv; this.viewer = viewer; this.page = page;
            refresh();
        }

        void refresh() {
            view = new ArrayList<>(ORDERS);
            view.sort((a, b) -> { int c = Double.compare(b.perItem, a.perItem); return c != 0 ? c : Long.compare(a.created, b.created); });
            pages = Math.max(1, (view.size() + PER_PAGE - 1) / PER_PAGE);
            page = Math.max(0, Math.min(page, pages - 1));
            for (int i = 0; i < 54; i++) inv.setStack(i, ItemStack.EMPTY);
            for (int i = 0; i < PER_PAGE; i++) {
                int idx = page * PER_PAGE + i;
                if (idx >= view.size()) break;
                Order o = view.get(idx);
                boolean own = o.buyer.equals(viewer);
                ItemStack d = o.template.copyWithCount(Math.max(1, Math.min(o.remaining, o.template.getMaxCount())));
                d.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                    Text.literal("§eGiá mua: §a$" + DonutLike.fmt(o.perItem) + "§e /cái"),
                    Text.literal("§7Còn cần: §f" + o.remaining),
                    Text.literal("§7Người đặt: " + o.buyerName),
                    Text.literal(own ? "§cClick để huỷ order (hoàn tiền)" : "§aClick để giao hàng (lấy từ túi bạn)"))));
                inv.setStack(i, d);
            }
            for (int i = 45; i < 54; i++) inv.setStack(i, named(Items.GRAY_STAINED_GLASS_PANE, " "));
            if (page > 0) inv.setStack(45, named(Items.ARROW, "§e← Trang trước"));
            inv.setStack(49, named(Items.PAPER, "§fTrang " + (page + 1) + "/" + pages, "§7" + view.size() + " order", "§7Tạo: /orders create <item> <sl> <giá/cái>"));
            if (page < pages - 1) inv.setStack(53, named(Items.ARROW, "§eTrang sau →"));
        }

        @Override
        public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
            if (slot >= 0 && slot < 54 && type == SlotActionType.PICKUP && player instanceof ServerPlayerEntity sp) {
                if (slot == 45 && page > 0) { int pg = page - 1; sp.getServer().execute(() -> openOrders(sp, pg)); }
                else if (slot == 53 && page < pages - 1) { int pg = page + 1; sp.getServer().execute(() -> openOrders(sp, pg)); }
                else if (slot < PER_PAGE) {
                    int idx = page * PER_PAGE + slot;
                    if (idx < view.size()) click(sp, view.get(idx));
                    refresh();
                }
            }
            syncState();
        }

        void click(ServerPlayerEntity sp, Order o) {
            if (!ORDERS.contains(o)) { DonutLike.msg(sp, "§cOrder này không còn."); return; }
            if (o.buyer.equals(sp.getUuid())) {
                ORDERS.remove(o);
                DonutLike.add(sp.getUuid(), o.perItem * o.remaining);
                DonutLike.msg(sp, "§eĐã huỷ order, hoàn $" + DonutLike.fmt(o.perItem * o.remaining));
                return;
            }
            ServerPlayerEntity buyer = sp.getServer().getPlayerManager().getPlayer(o.buyer);
            if (buyer == null) { refundOrders(o.buyer, false); DonutLike.msg(sp, "§cNgười đặt đã offline, order bị huỷ."); return; }
            int need = o.remaining, given = 0;
            PlayerInventory pi = sp.getInventory();
            for (int i = 0; i < 36 && given < need; i++) {
                ItemStack s = pi.getStack(i);
                if (s.isEmpty() || !ItemStack.areItemsAndComponentsEqual(s, o.template)) continue;
                int n = Math.min(s.getCount(), need - given);
                s.decrement(n);
                given += n;
            }
            if (given == 0) { DonutLike.msg(sp, "§cBạn không có vật phẩm phù hợp trong túi."); return; }
            double pay = o.perItem * given;
            DonutLike.add(sp.getUuid(), pay);
            o.remaining -= given;
            if (o.remaining <= 0) ORDERS.remove(o);
            int left = given;
            while (left > 0) {
                int n = Math.min(o.template.getMaxCount(), left);
                buyer.getInventory().offerOrDrop(o.template.copyWithCount(n));
                left -= n;
            }
            DonutLike.msg(sp, "§a[Order] Đã giao " + given + "x " + o.template.getName().getString() + ", nhận $" + DonutLike.fmt(pay));
            DonutLike.msg(buyer, "§a[Order] " + sp.getName().getString() + " đã giao " + given + "x " + o.template.getName().getString()
                + (o.remaining > 0 ? " (còn " + o.remaining + ")" : " — order hoàn tất"));
        }

        @Override public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
    }
}
