package com.donutlike;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Rarity;

import java.util.HashMap;
import java.util.Map;

/**
 * Gia ban cua MOI item / block (ke ca item chua co trong bang PRICES) + dinh dang tien 1K 1M 1B 1T.
 * Dung ca o client (tooltip) lan server nen KHONG duoc dung bat cu thu gi cua server o day.
 */
public class Prices {
    /** Ty le tien nhan duoc khi ban (1.0 = dung bang gia hien tren tooltip). */
    public static final double SELL_RATE = 1.0;
    /** Ty le gia mua trong /shop so voi gia ban. */
    public static final double BUY_RATE = 1.5;

    static final Map<Item, Double> CACHE = new HashMap<>();

    /** Gia tri 1 cai cua item (chua nhan SELL_RATE). */
    public static double unit(Item item) {
        Double c = CACHE.get(item);
        if (c != null) return c;
        double v = compute(item);
        CACHE.put(item, v);
        return v;
    }

    static double compute(Item item) {
        String id = Registries.ITEM.getId(item).getPath();
        Double fixed = DonutLike.PRICES.get(id);
        if (fixed != null) return fixed;
        // vat pham khong lay duoc / khong nen ban
        if (id.equals("air") || id.contains("command_block") || id.equals("barrier") || id.equals("bedrock")
                || id.equals("structure_block") || id.equals("structure_void") || id.equals("jigsaw")
                || id.equals("light") || id.equals("debug_stick") || id.equals("knowledge_book")
                || id.equals("reinforced_deepslate") || id.equals("end_portal_frame") || id.equals("petrified_oak_slab")
                || id.startsWith("test_")) return 0;
        if (id.contains("spawn_egg")) return 500;
        if (id.contains("netherite_ingot")) return 800;
        if (id.contains("netherite_scrap")) return 200;
        if (id.contains("ancient_debris")) return 220;
        if (id.contains("netherite_")) return 2500;
        if (id.contains("diamond_block")) return 900;
        if (id.contains("diamond_")) return 300;
        if (id.equals("diamond") || id.equals("diamond_ore") || id.equals("deepslate_diamond_ore")) return 100;
        if (id.contains("emerald_block")) return 360;
        if (id.contains("emerald")) return 40;
        if (id.contains("gold_block")) return 135;
        if (id.contains("raw_gold_block")) return 120;
        if (id.contains("golden_")) return 60;
        if (id.contains("gold")) return 15;
        if (id.contains("iron_block")) return 90;
        if (id.contains("iron_")) return 30;
        if (id.contains("iron")) return 10;
        if (id.contains("copper_block")) return 36;
        if (id.contains("copper")) return 4;
        if (id.contains("coal_block")) return 27;
        if (id.contains("coal")) return 3;
        if (id.contains("redstone_block")) return 27;
        if (id.contains("lapis_block")) return 36;
        if (id.contains("shulker_shell")) return 400;
        if (id.contains("shulker_box")) return 1000;
        if (id.contains("elytra")) return 3000;
        if (id.contains("totem")) return 1000;
        if (id.contains("nether_star")) return 5000;
        if (id.contains("beacon")) return 6000;
        if (id.contains("dragon_egg")) return 100000;
        if (id.contains("dragon_head")) return 20000;
        if (id.contains("enchanted_golden_apple")) return 2500;
        if (id.contains("trident")) return 1500;
        if (id.contains("mace")) return 5000;
        if (id.contains("heavy_core")) return 3000;
        if (id.contains("wind_charge") || id.contains("breeze_rod")) return 30;
        if (id.contains("echo_shard")) return 150;
        if (id.contains("music_disc")) return 300;
        if (id.contains("netherrack") || id.contains("cobblestone") || id.contains("dirt") || id.contains("sand")
                || id.contains("gravel") || id.contains("stone")) return 1;
        // theo do hiem cua vat pham
        double base;
        try {
            Rarity r = new ItemStack(item).getRarity();
            switch (r) {
                case UNCOMMON -> base = 20;
                case RARE -> base = 100;
                case EPIC -> base = 500;
                default -> base = 1;
            }
        } catch (Throwable t) { base = 1; }
        // do bo / cong cu thuong
        if (id.endsWith("_sword") || id.endsWith("_pickaxe") || id.endsWith("_axe") || id.endsWith("_shovel")
                || id.endsWith("_hoe") || id.endsWith("_helmet") || id.endsWith("_chestplate")
                || id.endsWith("_leggings") || id.endsWith("_boots")) base = Math.max(base, 8);
        return base;
    }

    /** Gia ban cua ca stack (nhan so luong, cong ca do ben trong shulker / bundle). */
    public static double stack(ItemStack s) {
        if (s == null || s.isEmpty()) return 0;
        double v = unit(s.getItem()) * s.getCount() * SELL_RATE;
        ContainerComponent cc = s.get(DataComponentTypes.CONTAINER);
        if (cc != null) {
            for (ItemStack in : cc.iterateNonEmpty()) v += stack(in);
        }
        return v;
    }

    /** 1 -> "1", 100000 -> "100K", 1500000 -> "1.5M", 104410000 -> "104.41M", 1e9 -> "1B", 1e12 -> "1T". */
    public static String money(double v) {
        String[] suf = {"", "K", "M", "B", "T"};
        int i = 0;
        double a = v;
        while (Math.abs(a) >= 1000 && i < suf.length - 1) { a /= 1000; i++; }
        String s = i == 0 ? (a == Math.rint(a) ? String.valueOf((long) a) : String.format("%.2f", a)) : String.format("%.2f", a);
        if (s.contains(".")) { s = s.replaceAll("0+$", ""); if (s.endsWith(".")) s = s.substring(0, s.length() - 1); }
        return s + suf[i];
    }

    /** Doc so kieu 1k 2.5m 1b 1t (cho lenh admin). Tra ve NaN neu sai. */
    public static double parse(String in) {
        try {
            String s = in.trim().toLowerCase().replace(",", "");
            double mul = 1;
            if (s.endsWith("k")) { mul = 1e3; s = s.substring(0, s.length() - 1); }
            else if (s.endsWith("m")) { mul = 1e6; s = s.substring(0, s.length() - 1); }
            else if (s.endsWith("b")) { mul = 1e9; s = s.substring(0, s.length() - 1); }
            else if (s.endsWith("t")) { mul = 1e12; s = s.substring(0, s.length() - 1); }
            return Double.parseDouble(s) * mul;
        } catch (Exception e) { return Double.NaN; }
    }
}
