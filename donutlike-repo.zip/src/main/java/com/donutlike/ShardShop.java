package com.donutlike;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static net.minecraft.server.command.CommandManager.literal;

/** /shardshop: mua do Amethyst + spawner bang Shard. SUA GIA SHARD O BANG PRICE_* ben duoi. */
public class ShardShop {

    // ten loai -> gia shard (do Amethyst)
    static final Map<String, Integer> TOOL_PRICE = new LinkedHashMap<>();
    // ten mob -> gia shard (spawner)
    static final Map<String, Integer> SPAWNER_PRICE = new LinkedHashMap<>();
    static {
        TOOL_PRICE.put("potion", 100);
        TOOL_PRICE.put("bucket", 150);
        TOOL_PRICE.put("pick_silk", 600);
        TOOL_PRICE.put("pick_fortune", 700);
        TOOL_PRICE.put("shovel_silk", 400);
        TOOL_PRICE.put("shovel_fortune", 450);
        TOOL_PRICE.put("treeaxe_silk", 300);
        TOOL_PRICE.put("treeaxe_fortune", 350);
        TOOL_PRICE.put("sellaxe_silk", 400);
        TOOL_PRICE.put("sellaxe_fortune", 450);
        SPAWNER_PRICE.put("pig", 100);
        SPAWNER_PRICE.put("cow", 100);
        SPAWNER_PRICE.put("skeleton", 400);
        SPAWNER_PRICE.put("blaze", 500);
        SPAWNER_PRICE.put("creeper", 600);
    }

    static ItemStack spawner(String mob) {
        ItemStack s = new ItemStack(Items.SPAWNER);
        NbtCompound be = new NbtCompound();
        be.putString("id", "minecraft:mob_spawner");
        NbtCompound ent = new NbtCompound();
        ent.putString("id", "minecraft:" + mob);
        NbtCompound sd = new NbtCompound();
        sd.put("entity", ent);
        be.put("SpawnData", sd);
        be.putShort("RequiredPlayerRange", (short) 0); // khong sinh quai that, chi sinh do vao kho (Spawners.java)
        NbtList pot = new NbtList();
        NbtCompound entry = new NbtCompound();
        entry.putInt("weight", 1);
        entry.put("data", sd.copy());
        pot.add(entry);
        be.put("SpawnPotentials", pot);
        s.set(DataComponentTypes.BLOCK_ENTITY_DATA, NbtComponent.of(be));
        String nm = mob.substring(0, 1).toUpperCase() + mob.substring(1);
        s.set(DataComponentTypes.CUSTOM_NAME, Text.literal("§d" + nm + " Spawner"));
        return s;
    }


    public static void open(ServerPlayerEntity p) {
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (id, inv, pl) -> new Gui(id, inv, new SimpleInventory(45)), Text.literal("Shard Shop")));
    }

    static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("shardshop").executes(c -> { open(c.getSource().getPlayerOrThrow()); return 1; }));
    }

    static class Gui extends GenericContainerScreenHandler {
        final SimpleInventory inv;
        final List<String> toolKeys = new ArrayList<>(TOOL_PRICE.keySet());
        final List<String> mobKeys = new ArrayList<>(SPAWNER_PRICE.keySet());

        Gui(int id, PlayerInventory pinv, SimpleInventory inv) {
            super(ScreenHandlerType.GENERIC_9X5, id, pinv, inv, 5);
            this.inv = inv;
            refresh(pinv.player);
        }

        void refresh(PlayerEntity pl) {
            ShopHandler.fill(inv);
            int sh = DonutLike.save.shards.getOrDefault(pl.getUuid().toString(), 0);
            inv.setStack(4, ShopHandler.icon(Items.EMERALD, "§d§lShard Shop", "§7Shards của bạn: §d" + sh));
            for (int i = 0; i < toolKeys.size() && i < 18; i++) {
                String k = toolKeys.get(i);
                ItemStack s = AntiLag.makeAmethyst(k);
                List<Text> lore = new ArrayList<>(s.getOrDefault(DataComponentTypes.LORE, LoreComponent.DEFAULT).lines());
                lore.add(Text.literal("§dGiá: " + TOOL_PRICE.get(k) + " shards"));
                lore.add(Text.literal("§aClick để mua"));
                s.set(DataComponentTypes.LORE, new LoreComponent(lore));
                inv.setStack(9 + i, s);
            }
            for (int i = 0; i < mobKeys.size() && i < 9; i++) {
                String k = mobKeys.get(i);
                ItemStack s = spawner(k);
                s.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                    Text.literal("§dGiá: " + SPAWNER_PRICE.get(k) + " shards"), Text.literal("§aClick để mua"))));
                inv.setStack(27 + i, s);
            }
            inv.setStack(40, ShopHandler.icon(Items.ARROW, "§eQuay lại Shop"));
        }

        @Override
        public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
            if (player instanceof ServerPlayerEntity sp && type == SlotActionType.PICKUP && button == 0 && slot >= 0 && slot < 45) {
                if (slot == 40) ShopHandler.later(sp, () -> ShopHandler.open(sp));
                else if (slot >= 9 && slot < 27 && slot - 9 < toolKeys.size()) {
                    String k = toolKeys.get(slot - 9);
                    pay(sp, TOOL_PRICE.get(k), AntiLag.makeAmethyst(k));
                } else if (slot >= 27 && slot < 36 && slot - 27 < mobKeys.size()) {
                    String k = mobKeys.get(slot - 27);
                    pay(sp, SPAWNER_PRICE.get(k), spawner(k));
                }
                refresh(sp);
            }
            syncState();
        }

        void pay(ServerPlayerEntity sp, int price, ItemStack give) {
            String id = sp.getUuid().toString();
            int have = DonutLike.save.shards.getOrDefault(id, 0);
            if (have < price) { DonutLike.msg(sp, "§cYou don't have enough shards! (cần " + price + ")"); return; }
            if (!ShopHandler.canReceive(sp, give.getItem(), 1)) return;
            DonutLike.save.shards.put(id, have - price);
            sp.getInventory().offerOrDrop(give);
            ShopHandler.ting(sp);
            DonutLike.msg(sp, "§aĐã mua §f" + give.getName().getString() + " §a- §d" + price + " shards");
        }

        @Override public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
    }
}
